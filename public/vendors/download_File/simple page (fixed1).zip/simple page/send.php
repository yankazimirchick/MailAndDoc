
<?
$to = "reception@savitarmed.ru;

mail($to,"$name",$tel);
echo "Ваше сообщение отправлено";
?>

